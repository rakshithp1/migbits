# Margin Works

An editorial design studio with a kinetic type composition, original architectural artwork, filterable work and a project enquiry form.

Extract the ZIP and open index.html. No package installation or network connection is needed.

PROMPT.md is an original MigBits build brief. Use it to extend or rebuild the design in your preferred framework.

All names, products, prices and booking times are fictional examples. Forms and cart actions have no backend.

Keep LICENSE.txt when modifying, distributing or selling copies. Review the final accessibility and connect your own services before production use.

Use the template colour selector and copy the resulting CSS after the original stylesheet. Original vector artwork and source remain separate from that adaptation.

https://github.com/rakshithp1/migbits/blob/main/resources/library/original-showcases.ts
