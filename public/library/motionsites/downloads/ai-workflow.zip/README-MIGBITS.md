# MigBits / AI Workflow Hero

This is a design prompt kit. Open MigBits-build-brief.md for the adapted brief; original/MotionSites-prompt.md is preserved unchanged.

5 code excerpts are included. One live React adaptation is bundled and built for the sandbox.

The preview starts motion automatically when a video is selected and honors pause/reduced motion. The original heavy frame-cache strategy is not used in the live adaptation.

Reference media is deduplicated and served separately to keep each source ZIP small. REFERENCE-ASSETS.json lists exact asset URLs and hashes; the preview needs those URLs reachable.

No external font binaries or service credentials are included. Upstream font links inside the original brief are references, not a font redistribution grant.

Retain MotionSites notices, separate adaptation notices and dependency licenses. Distribution is not a general MIT grant for upstream prompts/media.