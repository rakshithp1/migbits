This is a design reference record, not executable component code. Use its guidance and verify it against your project's current framework documentation.

Font and icon names are references; their binaries and external assets are not included or relicensed.

Supporting files: /imported/ui-ux-pro-max/support.zip

Pinned source, license and file integrity checked. Runtime, accessibility and dependency compatibility are not yet validated.