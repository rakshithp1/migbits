# Moving Company

Creator: mmrahmanbappi
Source: https://github.com/mmrahmanbappi/100-free-html-templates/blob/bab6ec6c8900450aab90989d217942a67ad9b16d/local-services/moving-company/index.html

Extract the ZIP and open index.html. No build, npm dependencies or remote CDN is required.

The upstream/ folder preserves original source with its MIT notice. Root index.html is the separately documented MigBits adaptation.

Replace fictional sample business content, connect your own backend and retain the included license notices. Forms, data and payments are demonstrations.

Use Pause motion or your operating system reduced-motion preference. Full production and accessibility review remains your responsibility.

Original single-file HTML/CSS/inline JavaScript retained separately with creator MIT notice.

Stock photography, external fonts, favicons, metadata and remote services are excluded from the runnable edition; original HTML references are preserved as text only.

Original MigBits geometric demo artwork and motion controls are separate adaptations. Forms and checkout are frontend demonstrations, not backend services.

No React conversion is claimed. System font fallback changes the upstream typography. Render validation is not a complete accessibility audit.

Mobile grid minimum widths and word wrapping are corrected for community-center and nonprofit-charity. Dynamic photo references and initially empty image viewers use original artwork.

The original download-promotion toolbar is removed from runnable pages; creator attribution and complete copyright notices remain. Photo credit labels reflect the replacement MigBits artwork.