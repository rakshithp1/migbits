An event page with a day-by-day schedule and frontend registration.

Open index.html. No build step or external assets required. Forms and carts are frontend demos. Connect production services yourself. Preserve LICENSE when selling or redistributing.