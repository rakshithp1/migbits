// Original Migbits UI kit generator. MIT. Copyright 2026 Migbits contributors.
(async function(){
 await figma.loadFontAsync({family:"Inter",style:"Regular"});
 await figma.loadFontAsync({family:"Inter",style:"Bold"});
 const accent="#217A63";
 function rgb(hex){return {r:parseInt(hex.slice(1,3),16)/255,g:parseInt(hex.slice(3,5),16)/255,b:parseInt(hex.slice(5,7),16)/255}}
 function paint(hex){return [{type:"SOLID",color:rgb(hex)}]}
 const page=figma.createPage();page.name="Migbits / SaaS foundations";await figma.setCurrentPageAsync(page);
 function text(parent,label,size=14,color="#26242C",bold=false){const n=figma.createText();n.fontName={family:"Inter",style:bold?"Bold":"Regular"};n.characters=label;n.fontSize=size;n.fills=paint(color);parent.appendChild(n);return n}
 function frame(name,w,h,color="#FFFFFF",component=false){const n=component?figma.createComponent():figma.createFrame();n.name=name;n.resize(w,h);n.fills=paint(color);n.cornerRadius=10;page.appendChild(n);return n}
 function auto(n){n.layoutMode="VERTICAL";n.paddingTop=n.paddingBottom=20;n.paddingLeft=n.paddingRight=20;n.itemSpacing=12;n.primaryAxisSizingMode="AUTO";n.counterAxisSizingMode="FIXED"}
 const tokens={primary:accent,ink:"#26242C",surface:"#FFFFFF",background:"#F7F6F3",muted:"#777777"};
 for(const [key,value] of Object.entries(tokens)){const style=figma.createPaintStyle();style.name="Migbits/saas/"+key;style.paints=paint(value)}
 const variants=[];
 for(const [index,state] of ["Primary","Secondary","Disabled"].entries()){
   const n=frame("Style="+state,160,44,state==="Primary"?accent:state==="Secondary"?"#EEEAF5":"#E5E5E5",true);n.x=48+index*190;n.y=100;n.layoutMode="HORIZONTAL";n.primaryAxisAlignItems="CENTER";n.counterAxisAlignItems="CENTER";n.paddingLeft=n.paddingRight=18;n.primaryAxisSizingMode="AUTO";text(n,"Button",14,state==="Primary"?"#FFFFFF":"#26242C");variants.push(n);
 }
 const buttons=figma.combineAsVariants(variants,page);buttons.name="Button";buttons.x=48;buttons.y=100;
 const field=frame("Input / Default",300,84,"#FFFFFF",true);auto(field);field.x=48;field.y=250;text(field,"Email address",12,"#777777");text(field,"you@example.com",14);
 const badge=frame("Badge / Default",110,32,"#EEEAF5",true);badge.x=400;badge.y=250;badge.layoutMode="HORIZONTAL";badge.primaryAxisAlignItems="CENTER";badge.counterAxisAlignItems="CENTER";text(badge,"New collection",11,accent);
 const card=frame("Card / Default",300,180,"#FFFFFF",true);auto(card);card.x=48;card.y=390;text(card,"A thoughtful detail",22,"#26242C",true);text(card,"Build something worth keeping.",14,"#777777");card.appendChild(variants[0].createInstance());
 const nav=frame("Block / Navigation",900,80,"#FFFFFF",true);nav.x=48;nav.y=650;nav.layoutMode="HORIZONTAL";nav.paddingLeft=nav.paddingRight=28;nav.counterAxisAlignItems="CENTER";nav.itemSpacing=60;text(nav,"saas.",24,"#26242C",true);text(nav,"Discover");text(nav,"About");nav.appendChild(variants[0].createInstance());
 const hero=frame("Block / Hero",900,270,"#FFFFFF",true);auto(hero);hero.x=48;hero.y=770;text(hero,"THOUGHTFULLY MADE",12,accent);text(hero,"Make room for better work.",38,"#26242C",true);text(hero,"An editable starting point for your next project.",16,"#777777");hero.appendChild(variants[0].createInstance());
 const pricing=frame("Block / Pricing",300,240,"#FFFFFF",true);auto(pricing);pricing.x=400;pricing.y=390;text(pricing,"Studio plan",22,"#26242C",true);text(pricing,"$24 / month",26);text(pricing,"Everything you need to begin.",14,"#777777");pricing.appendChild(variants[0].createInstance());
 const board=frame("Template / Starter",980,800,"#F7F6F3");board.x=1100;board.y=100;
 const navInstance=nav.createInstance();board.appendChild(navInstance);navInstance.x=40;navInstance.y=30;
 const heroInstance=hero.createInstance();board.appendChild(heroInstance);heroInstance.x=40;heroInstance.y=140;
 for(let i=0;i<3;i++){const instance=card.createInstance();board.appendChild(instance);instance.x=30+i*310;instance.y=450}
 text(page,"Original Migbits. MIT: preserve LICENSE when redistributing. Fonts remain separately licensed.",14,"#777777").y=1150;
 figma.viewport.scrollAndZoomIntoView([board]);figma.closePlugin("Created editable components, button variants, blocks, paint styles and a starter template.");
})().catch(error=>{figma.closePlugin("Could not generate kit: "+error.message)});
