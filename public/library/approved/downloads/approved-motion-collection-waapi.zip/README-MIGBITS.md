# Motion · Waapi examples

4 reviewed MIT Motion source variants in one collection. Original code, current client imports and dependency notices stay distinct. These are technical examples requiring production accessibility review.

Install React, React DOM and motion in your consuming project. The preview uses motion 14.6.0; original code imports framer-motion.

Copy Example.tsx into a client component and render its App export. Review fixed sizing, keyboard controls and reduced motion before production use.

Original source is unchanged under upstream/. Example.tsx only adds the Next client boundary and current motion/react import. The separate MigBits preview adds pause/reduced-motion handling; that wrapper is not silently claimed to be part of the upstream source.

No Motion+ components, website screenshots, photos or paid examples are included. The source is a technical example, not a complete application.

4 variants, not 4 separate gallery components or templates.