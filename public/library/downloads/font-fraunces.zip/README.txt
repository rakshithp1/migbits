Use font.css to self-host Fraunces. Preserve OFL.txt. The original font software and its names have not been modified.
