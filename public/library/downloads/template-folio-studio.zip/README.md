# Folio Studio

Open index.html directly. Single-file HTML, CSS and vanilla JavaScript; no framework, build step, network dependency or external font.

Full-viewport hero plus approach, contact and footer sections. Motion starts automatically. Pause preserves phase; reduced motion displays static artwork.

Original MigBits design and Canvas 2D artwork, MIT licensed. Retain the full copyright and permission notice when copying, modifying or redistributing.

Frontend demonstration only. Replace fictional content and example.com contact details, connect your own services and review CSP before production. No real account, infrastructure, music playback or contact backend is included.