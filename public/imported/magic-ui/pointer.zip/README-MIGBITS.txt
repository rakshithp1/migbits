Use the included registry definition with the shadcn CLI in a separate React/Tailwind project.

Resolve registryDependencies and apply css/cssVars from the definition. Media URLs in upstream demos are references; external media is not redistributed.

Supporting files: /imported/magic-ui/support.zip

Pinned source, license and file integrity checked. Runtime, accessibility and dependency compatibility are not yet validated.