# HyperUI announcements 2 · Dark

Source: https://github.com/markmead/hyperui/blob/252efcfe39161db6e67cd877da001ee248d2bbf6/public/examples/marketing/announcements/2-dark.html
Revision: 252efcfe39161db6e67cd877da001ee248d2bbf6
License: MIT

Retain all original source and dependency notices. Original files are unchanged. Previews use separate MigBits fixtures; review original prop interfaces, framework and dependency requirements before use. Native Figma and complete template packages are not implied.
