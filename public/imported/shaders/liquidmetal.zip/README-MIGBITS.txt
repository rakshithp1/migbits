Use the upstream Shaders framework package and its documented component exports. The definition relies on the engine and is not a standalone React component.

Supporting engine source and all framework package manifests are in the collection support pack. WebGPU device support is required; provide a static fallback and respect reduced motion.

Supporting files: /imported/shaders/support.zip

Pinned source, license and file integrity checked. Runtime, accessibility and dependency compatibility are not yet validated.