# Choice Poll

Source: https://github.com/nolly-studio/cult-ui/blob/7f031dc812f7bda10213bab62752dd6d080297ff/apps/www/registry/default/ui/choice-poll.tsx
Revision: 7f031dc812f7bda10213bab62752dd6d080297ff
License: MIT

Retain all original source and dependency notices. Original files are unchanged. Previews use separate MigBits fixtures; review original prop interfaces, framework and dependency requirements before use. Native Figma and complete template packages are not implied.
