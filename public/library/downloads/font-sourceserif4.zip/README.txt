Use font.css to self-host Source Serif 4. Preserve OFL.txt. The original font software and its names have not been modified.
