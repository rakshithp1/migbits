# Radix Colors · Light & dark scales

Source: https://github.com/radix-ui/colors/blob/dbdb85470547c7d34b9001f48fddb08ded335979/src/index.ts
Revision: dbdb85470547c7d34b9001f48fddb08ded335979
License: MIT

Retain all original source and dependency notices. Original files are unchanged. Previews use separate MigBits fixtures; review original prop interfaces, framework and dependency requirements before use. Native Figma and complete template packages are not implied.
