# Open Peeps · 72

Source: https://cdn.prod.website-files.com/5e51c674258ffe10d286d30a/5e535a0dd3992316ad553c2e_peep-72.svg
Revision: Snapshot 2026-10-25; content-addressed SHA256
License: CC0-1.0

Retain all original source and dependency notices. Original files are unchanged. Previews use separate MigBits fixtures; review original prop interfaces, framework and dependency requirements before use. Native Figma and complete template packages are not implied.
