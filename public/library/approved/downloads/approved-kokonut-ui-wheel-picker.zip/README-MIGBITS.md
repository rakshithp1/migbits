# Wheel Picker

Source: https://github.com/kokonut-labs/kokonutui/blob/3456b061a3371e7b9aa158c0bb75dca04f227239/components/kokonutui/wheel-picker.tsx
Revision: 3456b061a3371e7b9aa158c0bb75dca04f227239
License: MIT

Retain all original source and dependency notices. Original files are unchanged. Previews use separate MigBits fixtures; review original prop interfaces, framework and dependency requirements before use. Native Figma and complete template packages are not implied.
