A dashboard with searchable activity, navigation and a reporting chart.

Open index.html. No build step or external assets required. Forms and carts are frontend demos. Connect production services yourself. Preserve LICENSE when selling or redistributing.