# MigBits Coral CTA & Footer

Open index.html in a browser. The single HTML file embeds the font, static plate and continuous procedural smoke; no framework, build step, CDN or network request is needed.

Implementation follows a user-supplied design brief. It is branded for MigBits; the brief itself is not offered as an original MigBits prompt.

The coral smoke field and static plate are original MigBits work. The supplied third-party CloudFront files were not bundled because their redistribution rights were not verified.

Code and original media: MIT. Unmodified Inter font: SIL OFL 1.1. Retain both complete notices, also embedded in the HTML. The font may not be sold by itself.

This is a signup UI demonstration. Valid email submission displays a local confirmation and does not send data. Example contact details are not MigBits business contact information.

Connect your own signup service and update the restrictive CSP before production integration. The live Canvas smoke starts automatically, evolves without a playback reset, pauses with visibility/global/local controls, and stays still for reduced motion.