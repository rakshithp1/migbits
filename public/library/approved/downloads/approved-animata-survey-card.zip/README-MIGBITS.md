# Survey Card

Source: https://github.com/codse/animata/blob/e7478b835a3b5c4153e71f60666634e91bb38813/animata/card/survey-card.tsx
Revision: e7478b835a3b5c4153e71f60666634e91bb38813
License: MIT

Retain all original source and dependency notices. Original files are unchanged. Previews use separate MigBits fixtures; review original prop interfaces, framework and dependency requirements before use. Native Figma and complete template packages are not implied.
