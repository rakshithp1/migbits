Source kit only. The preview is a documentation overview; upstream installation, hooks, CMS, environment integration and package builds have not been executed or certified.

Download into a separate project, inspect the README and pinned package manifests, then install only the dependencies you intend to use. Existing project AGENTS.md, skills and hooks must not be overwritten automatically.

Original Unlicense grant and creator provenance are preserved. Dependencies and any assets you add retain their own licenses. Public branding/image binaries are excluded.

Source files are original; the MigBits overview and packaging are separate adaptations. This is not a rendered website template and does not count toward the 500-template target.