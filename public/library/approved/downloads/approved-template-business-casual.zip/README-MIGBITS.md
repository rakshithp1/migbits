# Business Casual — motion edition

Original creator: Start Bootstrap
Source: https://github.com/StartBootstrap/startbootstrap-business-casual/tree/b6f928934386a54e08c2e7f40ebd9e4d7510bba4

Extract the ZIP and open index.html. The runnable edition needs no package installation or CDN.

Original upstream HTML/CSS/scripts are in upstream/. The root pages use separate MigBits motion, navigation and original SVG artwork. Original stock photographs, fonts, favicons and icon libraries are not bundled.

Forms, purchases and external links are frontend demonstrations. Connect your own production backend and replace the demo content. Preserve LICENSE, BOOTSTRAP-LICENSE and MIGBITS-ADAPTATION-LICENSE.

Pause motion is available in every adapted page; OS reduced motion is respected. Render checks are not a full accessibility or production-readiness certification.

Original HTML, CSS and author scripts are preserved separately; third-party artwork/fonts/favicon binaries are excluded, not relicensed.

Runnable edition replaces image references with original MigBits SVG art, removes remote scripts/styles/fonts, and uses original MigBits native motion/navigation/form-demo controllers.

Bootstrap embedded CSS retains its exact version license. Original external animation/icon/form services are not bundled or executed; preview parity with those services is not claimed.
