A product landing page with features, pricing and a newsletter form.

Open index.html. No build step or external assets required. Forms and carts are frontend demos. Connect production services yourself. Preserve LICENSE when selling or redistributing.