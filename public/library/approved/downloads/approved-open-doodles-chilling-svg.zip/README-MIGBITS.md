# Open Doodles · chilling

Source: https://opendoodles.s3-us-west-1.amazonaws.com/chilling.svg
Revision: Snapshot 2026-10-25; content-addressed SHA256
License: CC0-1.0

Retain all original source and dependency notices. Original files are unchanged. Previews use separate MigBits fixtures; review original prop interfaces, framework and dependency requirements before use. Native Figma and complete template packages are not implied.
