"use client";
import { useState } from "react"
import { MotionConfig, motion } from "motion/react"

/**
 * An example of the tween transition type
 */

const style = {
    width: 100,
    height: 100,
    background: "white",
}

export const App = () => {
    const [state, setState] = useState(true)

    return (
        <MotionConfig transition={{ duration: 1 }}>
            <motion.div
                initial={{ display: "block" }}
                animate={{
                    display: state ? "block" : "none",
                    visibility: state ? "visible" : "hidden",
                    opacity: state ? 1 : 0.2,
                }}
                onUpdate={(latest: any) => console.log(latest)}
                style={style}
            />
            <button onClick={() => setState(!state)}>Toggle</button>
        </MotionConfig>
    )
}
