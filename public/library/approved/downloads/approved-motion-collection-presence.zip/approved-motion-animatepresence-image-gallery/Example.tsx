"use client";
import { motion, AnimatePresence, wrap } from "motion/react"
import { useState } from "react"

/**
 * An example of a single-image, single-child image gallery using AnimatePresence
 */

const variants = {
    enter: (delta: number) => ({
        x: delta > 0 ? 1000 : -1000,
        opacity: 0,
    }),
    center: {
        zIndex: 1,
        x: 0,
        opacity: 1,
    },
    exit: (delta: number) => ({
        zIndex: 0,
        x: delta < 0 ? 1000 : -1000,
        opacity: 0,
    }),
}

const Image = ({ src, paginate, delta }) => (
    <motion.img
        src={src}
        custom={delta}
        variants={variants}
        initial="enter"
        animate="center"
        exit="exit"
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={1}
        transition={{
            duration: 2,
        }}
        onDragEnd={(e, { offset, velocity }) => {
            const swipe = Math.abs(offset.x) * velocity.x

            if (swipe < -10000) {
                paginate(1)
            } else if (swipe > 10000) {
                paginate(-1)
            }
        }}
    />
)

export const App = () => {
    const [[page, delta], setPage] = useState([0, 0])
    const imageIndex = wrap(0, images.length, page)

    const paginate = (newDelta: number) => {
        setPage([page + newDelta, newDelta])
    }

    return (
        <div className="example-container">
            <AnimatePresence initial={false} custom={delta}>
                <Image
                    delta={delta}
                    paginate={paginate}
                    src={images[imageIndex]}
                    key={page}
                />
            </AnimatePresence>
            <div className="next" onClick={() => paginate(1)}>
                {">"}
            </div>
            <div className="prev" onClick={() => paginate(-1)}>
                {"<"}
            </div>
            <style>{`
.example-container {
  width: 100vw;
  height: 100vh;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
}

.next,
.prev {
  top: 50%;
  position: absolute;
  background: white;
  border-radius: 30px;
  width: 40px;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  user-select: none;
  cursor: pointer;
  font-weight: bold;
  font-size: 18px;
  z-index: 2;
}

.next {
  right: 10px;
}

.prev {
  left: 10px;
}

img {
  position: absolute;
  max-width: 100vw;
}

.refresh {
  padding: 10px;
  position: absolute;
  background: rgba(0, 0, 0, 0.4);
  border-radius: 10px;
  width: 20px;
  height: 20px;
  top: 10px;
  right: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
}
`}</style>
        </div>
    )
}

const images = [
    "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMjAwIDgwMCI+PHJlY3Qgd2lkdGg9IjEyMDAiIGhlaWdodD0iODAwIiBmaWxsPSJoc2woMTYzIDQwJSAxMyUpIi8+PGNpcmNsZSBjeD0iODgwIiBjeT0iMjQwIiByPSIxODAiIGZpbGw9ImhzbCgxNjMgNjUlIDY1JSkiLz48cGF0aCBkPSJNMCA4MDBWNTAwTDM1MCAxODAgNzgwIDgwMFoiIGZpbGw9ImhzbCgyNTMgNTUlIDQ1JSkiLz48cGF0aCBkPSJNMjIwIDgwMCA5MDAgMzAwIDEyMDAgNTYwVjgwMFoiIGZpbGw9ImhzbCgzNDMgNDUlIDMyJSkiLz48L3N2Zz4=",
    "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMjAwIDgwMCI+PHJlY3Qgd2lkdGg9IjEyMDAiIGhlaWdodD0iODAwIiBmaWxsPSJoc2woMTIgNDAlIDEzJSkiLz48Y2lyY2xlIGN4PSI4ODAiIGN5PSIyNDAiIHI9IjE4MCIgZmlsbD0iaHNsKDEyIDY1JSA2NSUpIi8+PHBhdGggZD0iTTAgODAwVjUwMEwzNTAgMTgwIDc4MCA4MDBaIiBmaWxsPSJoc2woMTAyIDU1JSA0NSUpIi8+PHBhdGggZD0iTTIyMCA4MDAgOTAwIDMwMCAxMjAwIDU2MFY4MDBaIiBmaWxsPSJoc2woMTkyIDQ1JSAzMiUpIi8+PC9zdmc+",
    "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMjAwIDgwMCI+PHJlY3Qgd2lkdGg9IjEyMDAiIGhlaWdodD0iODAwIiBmaWxsPSJoc2woMTE5IDQwJSAxMyUpIi8+PGNpcmNsZSBjeD0iODgwIiBjeT0iMjQwIiByPSIxODAiIGZpbGw9ImhzbCgxMTkgNjUlIDY1JSkiLz48cGF0aCBkPSJNMCA4MDBWNTAwTDM1MCAxODAgNzgwIDgwMFoiIGZpbGw9ImhzbCgyMDkgNTUlIDQ1JSkiLz48cGF0aCBkPSJNMjIwIDgwMCA5MDAgMzAwIDEyMDAgNTYwVjgwMFoiIGZpbGw9ImhzbCgyOTkgNDUlIDMyJSkiLz48L3N2Zz4=",
]
