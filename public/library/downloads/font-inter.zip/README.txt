Use font.css to self-host Inter. Preserve OFL.txt. The original font software and its names have not been modified.
