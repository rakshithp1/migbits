# Indigo Editorial

Original MigBits semantic theme. Light/dark CSS variables, decorative gradient, radius and typography roles.

1. Copy theme.css into your application's global styles.
2. Map the semantic variables through your existing Tailwind v4/shadcn @theme inline configuration. Add .dark to your theme root for dark mode.
3. Headings: Instrument Serif; body: Inter; code: Geist Mono. Font binaries are NOT included. Get the individually licensed families at https://migbits.com/library/typography and preserve their OFL notices.
4. Keep text on opaque semantic backgrounds; the decorative gradient is not a contrast-certified text surface.
5. Check keyboard focus, forced colors, disabled states and contrast in your final components.

CSS/theme data: MIT; retain LICENSE.txt.
