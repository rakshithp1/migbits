# Color icons and original motion

16 reviewed generic Microsoft Fluent SVGs. Keep Microsoft's MIT license and complete NOTICE. Original upstream SVGs are under original/; attributed copies under icons/ add license metadata. MigBits motion CSS is separate original MIT code. No brand marks are included.

Use an img.migbits-color-glyph inside a container with data-effect=bob|tilt|pulse|turn|pop|swing|none. Set data-playing=true to animate or use a focusable button for hover/focus motion. Include icon-motion.css. Reduced-motion users get static icons.
