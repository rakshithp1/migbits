# Dark Grid Lines

Source: https://github.com/megh-bari/pattern-craft/blob/1550af7903f50b4f19a1b44786f27ca01f3ef6ab/src/data/patterns.ts#L5302
Revision: 1550af7903f50b4f19a1b44786f27ca01f3ef6ab
License: MIT

Retain all original source and dependency notices. Original files are unchanged. Previews use separate MigBits fixtures; review original prop interfaces, framework and dependency requirements before use. Native Figma and complete template packages are not implied.
