Copy the original JSX into a React/Tailwind project. Inspect the original imports and CSS variables before use. The support pack includes reference styles and package manifests.

Replace placeholder links and demonstration content. Runtime, keyboard, contrast and reduced-motion checks remain specific to your integration.

Supporting files: /imported/inspo/support.zip

Pinned source, license and file integrity checked. Runtime, accessibility and dependency compatibility are not yet validated.