Original Migbits UI kit. MIT.

QUICK IMPORT: Drag board.svg into a Figma Design file for editable vector shapes.

NATIVE COMPONENTS: In the Figma desktop app choose Plugins > Development > New plugin > Figma design > Run once. Keep the generated plugin ID. Replace its code.js with this code.js; copy the other manifest fields while preserving that ID. Run the development plugin in an empty file. It creates button variants, input, badge, card, navigation, hero, pricing, a starter screen and paint styles. No network access.

Generator syntax and structure are checked. Native execution in your Figma account has not been verified. This package is SVG + plugin source, not a .fig binary. Inter is used by name; font binaries are not bundled. Preserve LICENSE when redistributing or selling copies.