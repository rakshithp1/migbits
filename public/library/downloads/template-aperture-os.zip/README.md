# Aperture OS

Open index.html directly; HTML, CSS and vanilla JavaScript, with no build, framework, CDN or external font. Product images are embedded.

Scroll naturally through the sticky product story. Scroll position drives parallax, scale, rotation, progress and chapter changes. No scroll hijacking or video timeline.

Use Pause effects to freeze transforms. Reduced motion uses a static normal-flow section; all three chapters also remain readable in the details section.

Code: MIT; retain LICENSE and embedded notices. Preserve ASSET-PROVENANCE.md for AI-generated concept imagery.

Frontend concept only: replace fictional names, example.com contact and sample workspace content. No account service, commerce, payment or product backend is connected.