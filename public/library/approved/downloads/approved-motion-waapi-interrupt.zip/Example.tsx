"use client";
import { motion } from "motion/react"

export const App = () => {
    return (
        <div
            style={{
                width: "375px",
                height: "812px",
                borderRadius: "16px",
                background: "linear-gradient(180deg, #35a1ea 0%, #2c8dcd 100%)",
                display: "flex",
                justifyContent: "center",
                alignContent: "center",
                flexFlow: "column",
            }}
        >
            <div
                style={{
                    position: "relative",
                    margin: "auto",
                    alignSelf: "center",
                    justifySelf: "center",
                    width: "120px",
                    height: "120px",
                }}
            >
                <motion.img
                    alt="avatar"
                    animate={{
                        scale: [1, 0.98, 1, 1, 1, 1],
                        y: [0, -20, 0, -2, 0, 0],
                        opacity: [0.2, 1, 0.2, 0.2, 0.2, 0.2],
                    }}
                    transition={{
                        duration: 2.5,
                        type: "spring",
                        bounce: 1,
                        repeat: Infinity,
                    }}
                    style={{
                        width: "120px",
                        height: "120px",
                        willChange: "opacity",
                        opacity: 0.8,
                        filter: "drop-shadow(0px 2px 2px rgba(0, 0, 0, 0.16))",
                    }}
                    className="avatar"
                    src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMjAwIDgwMCI+PHJlY3Qgd2lkdGg9IjEyMDAiIGhlaWdodD0iODAwIiBmaWxsPSJoc2woNDQgNDAlIDEzJSkiLz48Y2lyY2xlIGN4PSI4ODAiIGN5PSIyNDAiIHI9IjE4MCIgZmlsbD0iaHNsKDQ0IDY1JSA2NSUpIi8+PHBhdGggZD0iTTAgODAwVjUwMEwzNTAgMTgwIDc4MCA4MDBaIiBmaWxsPSJoc2woMTM0IDU1JSA0NSUpIi8+PHBhdGggZD0iTTIyMCA4MDAgOTAwIDMwMCAxMjAwIDU2MFY4MDBaIiBmaWxsPSJoc2woMjI0IDQ1JSAzMiUpIi8+PC9zdmc+"
                />
                <motion.div
                    style={{
                        opacity: 0,
                        position: "absolute",
                        height: "120px",
                        width: "120px",
                        border: "2px solid #fff",
                        borderRadius: "120px",
                        top: 0,
                        left: 0,
                    }}
                />
            </div>
        </div>
    )
}
