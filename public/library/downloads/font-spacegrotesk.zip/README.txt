Use font.css to self-host Space Grotesk. Preserve OFL.txt. The original font software and its names have not been modified.
